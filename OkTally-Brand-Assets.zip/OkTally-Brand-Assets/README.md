# OkTally Brand Assets

Arquivos oficiais da identidade visual do OkTally para uso no aplicativo macOS.

## Estrutura

- `brand/oktally-symbol-color.png`: símbolo colorido com transparência.
- `brand/oktally-symbol-dark.png`: símbolo monocromático escuro.
- `brand/oktally-symbol-light.png`: símbolo monocromático claro.
- `brand/oktally-wordmark-dark.png`: wordmark para fundos claros.
- `brand/oktally-wordmark-light.png`: wordmark para fundos escuros.
- `brand/oktally-logo-horizontal-dark.png`: lockup completo para fundos claros.
- `brand/oktally-logo-horizontal-light.png`: lockup completo para fundos escuros.
- `Assets.xcassets/AppIcon.appiconset/`: ícones do aplicativo prontos para o Xcode.
- `Assets.xcassets/MenuBar.imageset/`: ícone monocromático template da menu bar.

## Grafia oficial

**OkTally**

Use sempre `OkTally`, sem espaço e com `O` e `T` maiúsculos.

## Paleta operacional

- Charcoal: `#1B1D20`
- Off-white: `#F7F5F0`
- Volt Cyan: `#00B8F5`
- Neon Magenta: `#FF007F`
- Heat Orange: `#FF9D00`

## macOS

No Xcode, copie `Assets.xcassets` para o projeto. Para o ícone da menu bar, habilite o comportamento template:

```swift
statusItem.button?.image = NSImage(named: "MenuBar")
statusItem.button?.image?.isTemplate = true
```

O macOS aplicará automaticamente a cor correta ao ícone conforme o tema e o estado da menu bar.
